from flask import Flask, jsonify, request

app = Flask(__name__)

# Vienkārša datu struktūra kā "datu bāze"
tasks = [
    {"id": 1, "title": "Mācīties Python", "done": False},
    {"id": 2, "title": "Izveidot REST API", "done": False},
]

# Mājas lapa
@app.route('/')
def home():
    return "Sveiki! Šī ir mana RESTful API lietotne."

# GET - Atgriezt visu uzdevumu sarakstu
@app.route('/tasks', methods=['GET'])
def get_tasks():
    return jsonify(tasks)

# GET - Atgriezt konkrētu uzdevumu pēc id
@app.route('/tasks/<int:task_id>', methods=['GET'])
def get_task(task_id):
    task = next((t for t in tasks if t['id'] == task_id), None)
    if task:
        return jsonify(task)
    return jsonify({"error": "Uzdevums nav atrasts"}), 404

# POST - Pievienot jaunu uzdevumu
@app.route('/tasks', methods=['POST'])
def create_task():
    if not request.json or not 'title' in request.json:
        return jsonify({"error": "Nepieciešams lauks 'title'"}), 400
    new_task = {
        "id": tasks[-1]['id'] + 1 if tasks else 1,
        "title": request.json['title'],
        "done": False
    }
    tasks.append(new_task)
    return jsonify(new_task), 201

# PUT - Atjaunināt uzdevumu
@app.route('/tasks/<int:task_id>', methods=['PUT'])
def update_task(task_id):
    task = next((t for t in tasks if t['id'] == task_id), None)
    if not task:
        return jsonify({"error": "Uzdevums nav atrasts"}), 404
    if not request.json:
        return jsonify({"error": "Nav datu atjaunināšanai"}), 400
    task['title'] = request.json.get('title', task['title'])
    task['done'] = request.json.get('done', task['done'])
    return jsonify(task)

# DELETE - Dzēst uzdevumu
@app.route('/tasks/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    global tasks
    tasks = [t for t in tasks if t['id'] != task_id]
    return jsonify({"result": "Uzdevums dzēsts"})

if __name__ == '__main__':
    app.run(debug=True)
